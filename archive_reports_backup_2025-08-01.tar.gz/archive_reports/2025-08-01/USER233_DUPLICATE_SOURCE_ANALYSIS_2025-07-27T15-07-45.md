🔍 ИССЛЕДОВАНИЕ ИСТОЧНИКА ДУБЛИКАТОВ USER 233
==================================================
РЕЖИМ: ТОЛЬКО ЧТЕНИЕ, НИКАКИХ ИЗМЕНЕНИЙ

1️⃣ ДАННЫЕ USER 233:
   User ID: 233
   Username: newinsider1
   First Name: Insider"SUI🐦"🦈"SPELL✨"
   UNI Balance: 250201.222463 UNI
   TON Balance: 0.024756 TON
   UNI Deposit: 119452092
   Referred By: 232
   Ref Code: REF_1752921751383_mqxhmq
   Created: 2025-07-19T10:42:31.383
   Is Admin: false

2️⃣ КРУПНЫЕ ТРАНЗАКЦИИ USER 233 (>100K):
   [1] 2025-07-27T09:13:56.212764 | FARMING_DEPOSIT | 283738 UNI
       Description: UNI farming deposit: 283738
   [2] 2025-07-26T14:58:29.221471 | FARMING_DEPOSIT | 182811 UNI
       Description: UNI farming deposit: 182811
   [3] 2025-07-26T11:56:20.759435 | FARMING_DEPOSIT | 257600 UNI
       Description: UNI farming deposit: 257600
   [4] 2025-07-26T08:14:51.177226 | FARMING_DEPOSIT | 242308 UNI
       Description: UNI farming deposit: 242308
   [5] 2025-07-25T21:42:12.316493 | FARMING_DEPOSIT | 345862 UNI
       Description: UNI farming deposit: 345862
   [6] 2025-07-25T16:10:18.966895 | FARMING_DEPOSIT | 498963 UNI
       Description: UNI farming deposit: 498963
   [7] 2025-07-25T13:10:34.396549 | FARMING_DEPOSIT | 138339 UNI
       Description: UNI farming deposit: 138339
   [8] 2025-07-25T12:05:17.934417 | FARMING_DEPOSIT | 225758 UNI
       Description: UNI farming deposit: 225758
   [9] 2025-07-25T08:09:07.785517 | FARMING_DEPOSIT | 937700 UNI
       Description: UNI farming deposit: 937700
   [10] 2025-07-25T08:08:40.396774 | FARMING_DEPOSIT | 936105 UNI
       Description: UNI farming deposit: 936105
   [11] 2025-07-24T15:04:09.689819 | FARMING_DEPOSIT | 204000 UNI
       Description: UNI farming deposit: 204000
   [12] 2025-07-24T14:24:57.119422 | FARMING_DEPOSIT | 151000 UNI
       Description: UNI farming deposit: 151000
   [13] 2025-07-24T13:12:43.319241 | FARMING_DEPOSIT | 656582 UNI
       Description: UNI farming deposit: 656582
   [14] 2025-07-24T11:37:06.868907 | FARMING_DEPOSIT | 484332 UNI
       Description: UNI farming deposit: 484332
   [15] 2025-07-24T08:02:22.798727 | FARMING_DEPOSIT | 573390 UNI
       Description: UNI farming deposit: 573390
   [16] 2025-07-23T21:37:10.9347 | FARMING_DEPOSIT | 39517885 UNI
       Description: UNI farming deposit: 39517885
   [17] 2025-07-22T15:53:55.233 | REFERRAL_REWARD | 527986.08 UNI
       Description: Referral L1 from User 234: 527986.08000000 UNI (100%)
   [18] 2025-07-22T15:40:43.759 | FARMING_REWARD | 731347.47 UNI
       Description: UNI farming income: 731347.470000 UNI (rate: 0.01)
       🎯 ЭТО ИСТОЧНИК ДУБЛИКАТОВ! Проверяем происхождение...
   [19] 2025-07-22T15:39:21.896 | REFERRAL_REWARD | 527986.08 UNI
       Description: Referral L1 from User 234: 527986.08000000 UNI (100%)
   [20] 2025-07-22T15:35:44.337 | FARMING_REWARD | 731347.47 UNI
       Description: UNI farming income: 731347.470000 UNI (rate: 0.01)
       🎯 ЭТО ИСТОЧНИК ДУБЛИКАТОВ! Проверяем происхождение...
   [21] 2025-07-22T15:34:37.612 | REFERRAL_REWARD | 527986.08 UNI
       Description: Referral L1 from User 234: 527986.08000000 UNI (100%)
   [22] 2025-07-22T15:30:43.971 | FARMING_REWARD | 731347.47 UNI
       Description: UNI farming income: 731347.470000 UNI (rate: 0.01)
       🎯 ЭТО ИСТОЧНИК ДУБЛИКАТОВ! Проверяем происхождение...
   [23] 2025-07-22T15:29:14.365 | REFERRAL_REWARD | 527986.08 UNI
       Description: Referral L1 from User 234: 527986.08000000 UNI (100%)
   [24] 2025-07-22T15:25:41.403 | FARMING_REWARD | 731347.47 UNI
       Description: UNI farming income: 731347.470000 UNI (rate: 0.01)
       🎯 ЭТО ИСТОЧНИК ДУБЛИКАТОВ! Проверяем происхождение...
   [25] 2025-07-22T15:24:19.083 | REFERRAL_REWARD | 527986.08 UNI
       Description: Referral L1 from User 234: 527986.08000000 UNI (100%)
   [26] 2025-07-22T15:20:41.079 | FARMING_REWARD | 731347.47 UNI
       Description: UNI farming income: 731347.470000 UNI (rate: 0.01)
       🎯 ЭТО ИСТОЧНИК ДУБЛИКАТОВ! Проверяем происхождение...
   [27] 2025-07-22T15:19:17.884 | REFERRAL_REWARD | 527986.08 UNI
       Description: Referral L1 from User 234: 527986.08000000 UNI (100%)
   [28] 2025-07-22T15:15:42.736 | FARMING_REWARD | 731347.47 UNI
       Description: UNI farming income: 731347.470000 UNI (rate: 0.01)
       🎯 ЭТО ИСТОЧНИК ДУБЛИКАТОВ! Проверяем происхождение...
   [29] 2025-07-22T15:14:25.544 | REFERRAL_REWARD | 527986.08 UNI
       Description: Referral L1 from User 234: 527986.08000000 UNI (100%)
   [30] 2025-07-22T15:10:41.169 | FARMING_REWARD | 731347.47 UNI
       Description: UNI farming income: 731347.470000 UNI (rate: 0.01)
       🎯 ЭТО ИСТОЧНИК ДУБЛИКАТОВ! Проверяем происхождение...
   [31] 2025-07-22T15:09:32.711 | REFERRAL_REWARD | 527986.08 UNI
       Description: Referral L1 from User 234: 527986.08000000 UNI (100%)
   [32] 2025-07-22T15:05:59.268 | FARMING_REWARD | 731347.47 UNI
       Description: UNI farming income: 731347.470000 UNI (rate: 0.01)
       🎯 ЭТО ИСТОЧНИК ДУБЛИКАТОВ! Проверяем происхождение...
   [33] 2025-07-22T15:04:15.357 | REFERRAL_REWARD | 527986.08 UNI
       Description: Referral L1 from User 234: 527986.08000000 UNI (100%)
   [34] 2025-07-22T15:00:39.932 | FARMING_REWARD | 731347.47 UNI
       Description: UNI farming income: 731347.470000 UNI (rate: 0.01)
       🎯 ЭТО ИСТОЧНИК ДУБЛИКАТОВ! Проверяем происхождение...
   [35] 2025-07-22T14:58:59.482 | REFERRAL_REWARD | 527986.08 UNI
       Description: Referral L1 from User 234: 527986.08000000 UNI (100%)
   [36] 2025-07-22T14:55:39.518 | FARMING_REWARD | 731347.47 UNI
       Description: UNI farming income: 731347.470000 UNI (rate: 0.01)
       🎯 ЭТО ИСТОЧНИК ДУБЛИКАТОВ! Проверяем происхождение...
   [37] 2025-07-22T14:53:51.984 | REFERRAL_REWARD | 527986.08 UNI
       Description: Referral L1 from User 234: 527986.08000000 UNI (100%)
   [38] 2025-07-22T14:50:40.609 | FARMING_REWARD | 731347.47 UNI
       Description: UNI farming income: 731347.470000 UNI (rate: 0.01)
       🎯 ЭТО ИСТОЧНИК ДУБЛИКАТОВ! Проверяем происхождение...
   [39] 2025-07-22T14:48:54.483 | REFERRAL_REWARD | 527986.08 UNI
       Description: Referral L1 from User 234: 527986.08000000 UNI (100%)
   [40] 2025-07-22T14:45:39.952 | FARMING_REWARD | 731347.47 UNI
       Description: UNI farming income: 731347.470000 UNI (rate: 0.01)
       🎯 ЭТО ИСТОЧНИК ДУБЛИКАТОВ! Проверяем происхождение...
   [41] 2025-07-22T14:43:44.702 | REFERRAL_REWARD | 527986.08 UNI
       Description: Referral L1 from User 234: 527986.08000000 UNI (100%)
   [42] 2025-07-22T14:40:41.499 | FARMING_REWARD | 731347.47 UNI
       Description: UNI farming income: 731347.470000 UNI (rate: 0.01)
       🎯 ЭТО ИСТОЧНИК ДУБЛИКАТОВ! Проверяем происхождение...
   [43] 2025-07-22T14:39:26.779 | REFERRAL_REWARD | 527986.08 UNI
       Description: Referral L1 from User 234: 527986.08000000 UNI (100%)
   [44] 2025-07-22T14:35:44.769 | FARMING_REWARD | 731347.47 UNI
       Description: UNI farming income: 731347.470000 UNI (rate: 0.01)
       🎯 ЭТО ИСТОЧНИК ДУБЛИКАТОВ! Проверяем происхождение...
   [45] 2025-07-22T14:34:01.258 | REFERRAL_REWARD | 527986.08 UNI
       Description: Referral L1 from User 234: 527986.08000000 UNI (100%)
   [46] 2025-07-22T14:30:39.118 | FARMING_REWARD | 731347.47 UNI
       Description: UNI farming income: 731347.470000 UNI (rate: 0.01)
       🎯 ЭТО ИСТОЧНИК ДУБЛИКАТОВ! Проверяем происхождение...
   [47] 2025-07-22T14:29:10.135 | REFERRAL_REWARD | 527986.08 UNI
       Description: Referral L1 from User 234: 527986.08000000 UNI (100%)
   [48] 2025-07-22T14:25:40.037 | FARMING_REWARD | 731347.47 UNI
       Description: UNI farming income: 731347.470000 UNI (rate: 0.01)
       🎯 ЭТО ИСТОЧНИК ДУБЛИКАТОВ! Проверяем происхождение...
   [49] 2025-07-22T14:24:24.598 | REFERRAL_REWARD | 527986.08 UNI
       Description: Referral L1 from User 234: 527986.08000000 UNI (100%)
   [50] 2025-07-22T14:23:48.602 | FARMING_REWARD | 585786.1 UNI
       Description: UNI farming income: 585786.100000 UNI (rate: 0.01)
   [51] 2025-07-22T14:22:09.955271 | FARMING_DEPOSIT | 14489325 UNI
       Description: UNI farming deposit: 14489325
   [52] 2025-07-22T14:19:26.16 | REFERRAL_REWARD | 527986.08 UNI
       Description: Referral L1 from User 234: 527986.08000000 UNI (100%)
   [53] 2025-07-22T14:19:05.341 | FARMING_REWARD | 585786.1 UNI
       Description: UNI farming income: 585786.100000 UNI (rate: 0.01)
   [54] 2025-07-22T14:14:03.487 | REFERRAL_REWARD | 527986.08 UNI
       Description: Referral L1 from User 234: 527986.08000000 UNI (100%)
   [55] 2025-07-22T14:13:43.896 | FARMING_REWARD | 585786.1 UNI
       Description: UNI farming income: 585786.100000 UNI (rate: 0.01)
   [56] 2025-07-22T14:09:02.632 | REFERRAL_REWARD | 527986.08 UNI
       Description: Referral L1 from User 234: 527986.08000000 UNI (100%)
   [57] 2025-07-22T14:08:43.93 | FARMING_REWARD | 585786.1 UNI
       Description: UNI farming income: 585786.100000 UNI (rate: 0.01)
   [58] 2025-07-22T14:04:19.171 | REFERRAL_REWARD | 527986.08 UNI
       Description: Referral L1 from User 234: 527986.08000000 UNI (100%)
   [59] 2025-07-22T14:03:48.678 | FARMING_REWARD | 585786.1 UNI
       Description: UNI farming income: 585786.100000 UNI (rate: 0.01)
   [60] 2025-07-22T13:59:24.563 | REFERRAL_REWARD | 527986.08 UNI
       Description: Referral L1 from User 234: 527986.08000000 UNI (100%)
   [61] 2025-07-22T13:58:50.121 | FARMING_REWARD | 585786.1 UNI
       Description: UNI farming income: 585786.100000 UNI (rate: 0.01)
   [62] 2025-07-22T13:54:34.149 | REFERRAL_REWARD | 527986.08 UNI
       Description: Referral L1 from User 234: 527986.08000000 UNI (100%)
   [63] 2025-07-22T13:53:59.611 | FARMING_REWARD | 585786.1 UNI
       Description: UNI farming income: 585786.100000 UNI (rate: 0.01)
   [64] 2025-07-22T13:49:16.743 | REFERRAL_REWARD | 527986.08 UNI
       Description: Referral L1 from User 234: 527986.08000000 UNI (100%)
   [65] 2025-07-22T13:48:42.289 | FARMING_REWARD | 585786.1 UNI
       Description: UNI farming income: 585786.100000 UNI (rate: 0.01)
   [66] 2025-07-22T13:43:36.325 | FARMING_REWARD | 585786.1 UNI
       Description: UNI farming income: 585786.100000 UNI (rate: 0.01)
   [67] 2025-07-22T13:42:19.095 | REFERRAL_REWARD | 501018.25 UNI
       Description: Referral L1 from User 234: 501018.25000000 UNI (100%)
   [68] 2025-07-22T13:38:52.803 | FARMING_REWARD | 585786.1 UNI
       Description: UNI farming income: 585786.100000 UNI (rate: 0.01)
   [69] 2025-07-22T13:38:42.568 | REFERRAL_REWARD | 430789.68 UNI
       Description: Referral L1 from User 234: 430789.68000000 UNI (100%)
   [70] 2025-07-22T13:33:52.027 | FARMING_REWARD | 585786.1 UNI
       Description: UNI farming income: 585786.100000 UNI (rate: 0.01)
   [71] 2025-07-22T13:33:42.577 | REFERRAL_REWARD | 430789.68 UNI
       Description: Referral L1 from User 234: 430789.68000000 UNI (100%)
   [72] 2025-07-22T13:28:36.741 | FARMING_REWARD | 585786.1 UNI
       Description: UNI farming income: 585786.100000 UNI (rate: 0.01)
   [73] 2025-07-22T13:28:27.11 | REFERRAL_REWARD | 430789.68 UNI
       Description: Referral L1 from User 234: 430789.68000000 UNI (100%)
   [74] 2025-07-22T13:23:56.970814 | FARMING_DEPOSIT | 861684 UNI
       Description: UNI farming deposit: 861684
   [75] 2025-07-22T13:23:41.460156 | FARMING_DEPOSIT | 193300 UNI
       Description: UNI farming deposit: 193300
   [76] 2025-07-22T13:23:36.499 | REFERRAL_REWARD | 430789.68 UNI
       Description: Referral L1 from User 234: 430789.68000000 UNI (100%)
   [77] 2025-07-22T13:23:25.448684 | FARMING_DEPOSIT | 5496735 UNI
       Description: UNI farming deposit: 5496735
   [78] 2025-07-22T13:22:34.961 | FARMING_REWARD | 520268.91 UNI
       Description: UNI farming income: 520268.910000 UNI (rate: 0.01)
   [79] 2025-07-22T13:18:15.096 | REFERRAL_REWARD | 430789.68 UNI
       Description: Referral L1 from User 234: 430789.68000000 UNI (100%)
   [80] 2025-07-22T13:17:10.269 | FARMING_REWARD | 520268.91 UNI
       Description: UNI farming income: 520268.910000 UNI (rate: 0.01)
   [81] 2025-07-22T13:13:35.843 | REFERRAL_REWARD | 430789.68 UNI
       Description: Referral L1 from User 234: 430789.68000000 UNI (100%)
   [82] 2025-07-22T13:12:27.672 | FARMING_REWARD | 520268.91 UNI
       Description: UNI farming income: 520268.910000 UNI (rate: 0.01)
   [83] 2025-07-22T13:09:01.7 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [84] 2025-07-22T13:07:48.596 | FARMING_REWARD | 520268.91 UNI
       Description: UNI farming income: 520268.910000 UNI (rate: 0.01)
   [85] 2025-07-22T13:04:35.972636 | FARMING_DEPOSIT | 306673 UNI
       Description: UNI farming deposit: 306673
   [86] 2025-07-22T13:04:11.475218 | FARMING_DEPOSIT | 193405 UNI
       Description: UNI farming deposit: 193405
   [87] 2025-07-22T13:04:04.11 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [88] 2025-07-22T13:03:52.895 | FARMING_REWARD | 351018.13 UNI
       Description: UNI farming income: 351018.130000 UNI (rate: 0.01)
   [89] 2025-07-22T13:03:25.210979 | FARMING_DEPOSIT | 16335330 UNI
       Description: UNI farming deposit: 16335330
   [90] 2025-07-22T12:59:05.742 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [91] 2025-07-22T12:58:54.971 | FARMING_REWARD | 351018.13 UNI
       Description: UNI farming income: 351018.130000 UNI (rate: 0.01)
   [92] 2025-07-22T12:53:57.218 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [93] 2025-07-22T12:53:46.1 | FARMING_REWARD | 351018.13 UNI
       Description: UNI farming income: 351018.130000 UNI (rate: 0.01)
   [94] 2025-07-22T12:48:45.087 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [95] 2025-07-22T12:48:34.387 | FARMING_REWARD | 351018.13 UNI
       Description: UNI farming income: 351018.130000 UNI (rate: 0.01)
   [96] 2025-07-22T12:43:58.964 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [97] 2025-07-22T12:43:47.52 | FARMING_REWARD | 351018.13 UNI
       Description: UNI farming income: 351018.130000 UNI (rate: 0.01)
   [98] 2025-07-22T12:38:39.773 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [99] 2025-07-22T12:38:28.425 | FARMING_REWARD | 351018.13 UNI
       Description: UNI farming income: 351018.130000 UNI (rate: 0.01)
   [100] 2025-07-22T12:33:33.548 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [101] 2025-07-22T12:33:23.074 | FARMING_REWARD | 351018.13 UNI
       Description: UNI farming income: 351018.130000 UNI (rate: 0.01)
   [102] 2025-07-22T12:28:38.967 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [103] 2025-07-22T12:28:28.601 | FARMING_REWARD | 351018.13 UNI
       Description: UNI farming income: 351018.130000 UNI (rate: 0.01)
   [104] 2025-07-22T12:23:42.324 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [105] 2025-07-22T12:23:32.043 | FARMING_REWARD | 351018.13 UNI
       Description: UNI farming income: 351018.130000 UNI (rate: 0.01)
   [106] 2025-07-22T12:18:33.334 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [107] 2025-07-22T12:18:22.719 | FARMING_REWARD | 351018.13 UNI
       Description: UNI farming income: 351018.130000 UNI (rate: 0.01)
   [108] 2025-07-22T12:13:24.81 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [109] 2025-07-22T12:13:14.216 | FARMING_REWARD | 351018.13 UNI
       Description: UNI farming income: 351018.130000 UNI (rate: 0.01)
   [110] 2025-07-22T12:08:18.096 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [111] 2025-07-22T12:08:07.758 | FARMING_REWARD | 351018.13 UNI
       Description: UNI farming income: 351018.130000 UNI (rate: 0.01)
   [112] 2025-07-22T12:03:55.803 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [113] 2025-07-22T12:03:53.989 | FARMING_REWARD | 351018.13 UNI
       Description: UNI farming income: 351018.130000 UNI (rate: 0.01)
   [114] 2025-07-22T11:59:07.595 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [115] 2025-07-22T11:59:05.683 | FARMING_REWARD | 351018.13 UNI
       Description: UNI farming income: 351018.130000 UNI (rate: 0.01)
   [116] 2025-07-22T11:53:46.899 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [117] 2025-07-22T11:53:45.048 | FARMING_REWARD | 351018.13 UNI
       Description: UNI farming income: 351018.130000 UNI (rate: 0.01)
   [118] 2025-07-22T11:49:00.728 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [119] 2025-07-22T11:48:47.562 | FARMING_REWARD | 351018.13 UNI
       Description: UNI farming income: 351018.130000 UNI (rate: 0.01)
   [120] 2025-07-22T11:44:07.065 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [121] 2025-07-22T11:43:53.448 | FARMING_REWARD | 351018.13 UNI
       Description: UNI farming income: 351018.130000 UNI (rate: 0.01)
   [122] 2025-07-22T11:35:13.418 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [123] 2025-07-22T11:35:11.643 | FARMING_REWARD | 351018.13 UNI
       Description: UNI farming income: 351018.130000 UNI (rate: 0.01)
   [124] 2025-07-22T11:28:36.661 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [125] 2025-07-22T11:28:34.83 | FARMING_REWARD | 351018.13 UNI
       Description: UNI farming income: 351018.130000 UNI (rate: 0.01)
   [126] 2025-07-22T11:23:20.967 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [127] 2025-07-22T11:23:19.143 | FARMING_REWARD | 351018.13 UNI
       Description: UNI farming income: 351018.130000 UNI (rate: 0.01)
   [128] 2025-07-22T11:13:38.812 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [129] 2025-07-22T11:13:04.333928 | FARMING_DEPOSIT | 31078244 UNI
       Description: UNI farming deposit: 31078244
   [130] 2025-07-22T11:08:32.185 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [131] 2025-07-22T11:03:36.577 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [132] 2025-07-22T10:58:44.364 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [133] 2025-07-22T10:53:39.872 | REFERRAL_REWARD | 153377.88 UNI
       Description: Referral L1 from User 234: 153377.88000000 UNI (100%)
   [134] 2025-07-22T10:49:01.191 | REFERRAL_REWARD | 152845.31791667 UNI
       Description: Referral L1 from User 234: 152845.31791667 UNI (100%)
   [135] 2025-07-22T10:43:49.372 | REFERRAL_REWARD | 152312.75583333 UNI
       Description: Referral L1 from User 234: 152312.75583333 UNI (100%)
   [136] 2025-07-22T10:38:34.203 | REFERRAL_REWARD | 151780.19375 UNI
       Description: Referral L1 from User 234: 151780.19375000 UNI (100%)
   [137] 2025-07-22T10:33:27.828 | REFERRAL_REWARD | 151247.63166667 UNI
       Description: Referral L1 from User 234: 151247.63166667 UNI (100%)
   [138] 2025-07-22T10:24:33.498 | REFERRAL_REWARD | 150182.5075 UNI
       Description: Referral L1 from User 234: 150182.50750000 UNI (100%)
   [139] 2025-07-22T10:18:03.904 | REFERRAL_REWARD | 149649.94541667 UNI
       Description: Referral L1 from User 234: 149649.94541667 UNI (100%)
   [140] 2025-07-22T10:13:16.598 | REFERRAL_REWARD | 149117.38333333 UNI
       Description: Referral L1 from User 234: 149117.38333333 UNI (100%)
   [141] 2025-07-22T10:07:51.585 | REFERRAL_REWARD | 148584.82125 UNI
       Description: Referral L1 from User 234: 148584.82125000 UNI (100%)
   [142] 2025-07-22T10:03:10.004 | REFERRAL_REWARD | 148052.25916667 UNI
       Description: Referral L1 from User 234: 148052.25916667 UNI (100%)
   [143] 2025-07-22T09:58:04.637 | REFERRAL_REWARD | 147519.69708333 UNI
       Description: Referral L1 from User 234: 147519.69708333 UNI (100%)
   [144] 2025-07-22T09:53:10.428 | REFERRAL_REWARD | 146987.135 UNI
       Description: Referral L1 from User 234: 146987.13500000 UNI (100%)
   [145] 2025-07-22T09:48:08.508 | REFERRAL_REWARD | 146454.57291667 UNI
       Description: Referral L1 from User 234: 146454.57291667 UNI (100%)
   [146] 2025-07-22T09:43:07.739 | REFERRAL_REWARD | 145922.01083333 UNI
       Description: Referral L1 from User 234: 145922.01083333 UNI (100%)
   [147] 2025-07-22T09:38:04.987 | REFERRAL_REWARD | 145389.44875 UNI
       Description: Referral L1 from User 234: 145389.44875000 UNI (100%)
   [148] 2025-07-22T09:33:20.194 | REFERRAL_REWARD | 144856.88666667 UNI
       Description: Referral L1 from User 234: 144856.88666667 UNI (100%)
   [149] 2025-07-22T09:28:34.15 | REFERRAL_REWARD | 144324.32458333 UNI
       Description: Referral L1 from User 234: 144324.32458333 UNI (100%)
   [150] 2025-07-22T09:28:32.371 | REFERRAL_REWARD | 144324.32458333 UNI
       Description: Referral L1 from User 234: 144324.32458333 UNI (100%)
   [151] 2025-07-22T09:23:39.176 | REFERRAL_REWARD | 143791.7625 UNI
       Description: Referral L1 from User 234: 143791.76250000 UNI (100%)
   [152] 2025-07-22T09:23:27.822 | REFERRAL_REWARD | 143791.7625 UNI
       Description: Referral L1 from User 234: 143791.76250000 UNI (100%)
   [153] 2025-07-22T09:18:32.993 | REFERRAL_REWARD | 143259.20041667 UNI
       Description: Referral L1 from User 234: 143259.20041667 UNI (100%)
   [154] 2025-07-22T09:18:32.59 | REFERRAL_REWARD | 143259.20041667 UNI
       Description: Referral L1 from User 234: 143259.20041667 UNI (100%)
   [155] 2025-07-22T09:13:34.899 | REFERRAL_REWARD | 142726.63833333 UNI
       Description: Referral L1 from User 234: 142726.63833333 UNI (100%)
   [156] 2025-07-22T09:13:25.831 | REFERRAL_REWARD | 142726.63833333 UNI
       Description: Referral L1 from User 234: 142726.63833333 UNI (100%)
   [157] 2025-07-22T09:08:29.327 | REFERRAL_REWARD | 142194.07625 UNI
       Description: Referral L1 from User 234: 142194.07625000 UNI (100%)
   [158] 2025-07-22T09:08:27.486 | REFERRAL_REWARD | 142194.07625 UNI
       Description: Referral L1 from User 234: 142194.07625000 UNI (100%)
   [159] 2025-07-22T09:03:32.921 | REFERRAL_REWARD | 141661.51416667 UNI
       Description: Referral L1 from User 234: 141661.51416667 UNI (100%)
   [160] 2025-07-22T08:52:36.134 | REFERRAL_REWARD | 140063.82791667 UNI
       Description: Referral L1 from User 234: 140063.82791667 UNI (100%)
   [161] 2025-07-22T08:40:46.201 | REFERRAL_REWARD | 101782.0975 UNI
       Description: Referral L1 from User 234: 101782.09750000 UNI (100%)
   [162] 2025-07-22T08:34:05.462 | REFERRAL_REWARD | 101392.12777778 UNI
       Description: Referral L1 from User 234: 101392.12777778 UNI (100%)
   [163] 2025-07-22T08:29:49.037 | REFERRAL_REWARD | 101002.15805556 UNI
       Description: Referral L1 from User 234: 101002.15805556 UNI (100%)
   [164] 2025-07-22T08:24:04.129 | REFERRAL_REWARD | 100612.18833333 UNI
       Description: Referral L1 from User 234: 100612.18833333 UNI (100%)
   [165] 2025-07-22T08:19:41.067 | REFERRAL_REWARD | 100222.21861111 UNI
       Description: Referral L1 from User 234: 100222.21861111 UNI (100%)
   [166] 2025-07-21T19:41:08.520008 | FARMING_DEPOSIT | 1400000 UNI
       Description: UNI farming deposit: 1400000
   [167] 2025-07-21T18:14:42.114774 | FARMING_DEPOSIT | 1504000 UNI
       Description: UNI farming deposit: 1504000
   [168] 2025-07-21T15:45:59.086983 | FARMING_DEPOSIT | 163800 UNI
       Description: UNI farming deposit: 163800
   [169] 2025-07-21T15:21:01.296442 | FARMING_DEPOSIT | 213500 UNI
       Description: UNI farming deposit: 213500
   [170] 2025-07-21T14:33:59.313703 | FARMING_DEPOSIT | 190000 UNI
       Description: UNI farming deposit: 190000

3️⃣ ВСЕ ТРАНЗАКЦИИ С СУММОЙ 731347.47 UNI:
   📊 ВСЕГО НАЙДЕНО: 32 транзакций
   💰 ОБЩАЯ СУММА: 23,403,119.04 UNI

   РАСПРЕДЕЛЕНИЕ ПО ПОЛЬЗОВАТЕЛЯМ:
   User 25: 16 транзакций = 11,701,559.52 UNI
   User 233: 16 транзакций = 11,701,559.52 UNI

   ХРОНОЛОГИЯ ДУБЛИКАТОВ (первые 10):
   [1] 2025-07-22T14:25:40.037 | User 233 | UNI farming income: 731347.470000 UNI (rate: 0.01)...
   [2] 2025-07-22T14:25:40.737 | User 25 | Referral L1 from User 233: 731347.47000000 UNI (100%)...
   [3] 2025-07-22T14:30:39.118 | User 233 | UNI farming income: 731347.470000 UNI (rate: 0.01)...
   [4] 2025-07-22T14:30:39.818 | User 25 | Referral L1 from User 233: 731347.47000000 UNI (100%)...
   [5] 2025-07-22T14:35:44.769 | User 233 | UNI farming income: 731347.470000 UNI (rate: 0.01)...
   [6] 2025-07-22T14:35:45.587 | User 25 | Referral L1 from User 233: 731347.47000000 UNI (100%)...
   [7] 2025-07-22T14:40:41.499 | User 233 | UNI farming income: 731347.470000 UNI (rate: 0.01)...
   [8] 2025-07-22T14:40:42.24 | User 25 | Referral L1 from User 233: 731347.47000000 UNI (100%)...
   [9] 2025-07-22T14:45:39.952 | User 233 | UNI farming income: 731347.470000 UNI (rate: 0.01)...
   [10] 2025-07-22T14:45:40.661 | User 25 | Referral L1 from User 233: 731347.47000000 UNI (100%)...

   ⏱️  ВРЕМЕННОЙ АНАЛИЗ:
   Первая транзакция: 2025-07-22T14:25:40.037Z
   Последняя: 2025-07-22T15:40:44.533Z
   Общая продолжительность: 75 минут
   Средний интервал: 145 секунд

4️⃣ АКТИВНОСТЬ ДУБЛИКАТОВ В ПОСЛЕДНИЙ ЧАС:
   ✅ НОВЫХ ДУБЛИКАТОВ НЕ НАЙДЕНО
   💡 ИСТОЧНИК ДУБЛИКАТОВ НЕАКТИВЕН ИЛИ ИСПРАВЛЕН

5️⃣ АНАЛИЗ КРУПНЫХ РЕФЕРАЛЬНЫХ НАГРАД:
   РАСПРЕДЕЛЕНИЕ ПО СУММАМ:
   1000000 UNI: 7 транзакций
       🚨 ПОДОЗРИТЕЛЬНО МНОГО ПОВТОРОВ!
   455810 UNI: 3 транзакций
   585000 UNI: 3 транзакций
   527986.08 UNI: 3 транзакций
   795263.4 UNI: 3 транзакций
   530654.8 UNI: 3 транзакций
   477127.37 UNI: 3 транзакций
   650126.05054 UNI: 3 транзакций
   254117.79 UNI: 3 транзакций
   841581.57 UNI: 3 транзакций
   448814.72 UNI: 3 транзакций
   731347.47 UNI: 3 транзакций
   530732.99 UNI: 3 транзакций
   660914.4934 UNI: 2 транзакций
   197402.75666 UNI: 1 транзакций
   103188.190742 UNI: 1 транзакций
   793755.3134 UNI: 1 транзакций
   194798.06666 UNI: 1 транзакций
   184850.62666 UNI: 1 транзакций

🎯 ВЫВОДЫ И РЕКОМЕНДАЦИИ:
========================================
✅ ХОРОШАЯ НОВОСТЬ: Новые дубликаты не создаются
   ИСТОЧНИК ПРОБЛЕМЫ: Исторические дубликаты

📊 МАСШТАБ ПРОБЛЕМЫ:
   Всего дубликатов: 32
   Общий ущерб: 23,403,119.04 UNI
   Затронуто пользователей: 2

📋 ПЛАН ДЕЙСТВИЙ:
   ПРИОРИТЕТ 1: Создать backup данных
   ПРИОРИТЕТ 2: Пометить дубликаты для удаления
   ПРИОРИТЕТ 3: Пересчитать балансы пользователей
   ПРИОРИТЕТ 4: Внедрить мониторинг дубликатов